import assets from "@sa/assets";
const data = [
  {
    id: 1,
    Image: assets.gallery1.src,
    name: "1",
  },
  {
    id: 2,
    Image: assets.gallery2.src,
    name: "si",
  },
  {
    id: 3,
    Image: assets.gellery3.src,
    name: "sqdqhi",
  },
  {
    id: 4,
    Image: assets.gallery1.src,
    name: "jjk",
  },

  {
    id: 5,
    Image: assets.gallery1.src,
    name: "1",
  },
  {
    id: 6,
    Image: assets.gallery2.src,
    name: "si",
  },
  {
    id: 7,
    Image: assets.gellery3.src,
    name: "sqdqhi",
  },
  {
    id: 8,
    Image: assets.gallery1.src,
    name: "jjk",
  },
];

export default data;
