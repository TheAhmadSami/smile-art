import assets from "@sa/assets";

const data = [
  {
    id: 1,
    title: "أحمد مجدي",
    image: assets.t1.src,
    description: "الزمالة البريطانية في طب الأسنان من جامعة لندن",
  },
  {
    id: 2,
    title: "أحمد مجدي",
    image: assets.t2.src,
    description: "الزمالة البريطانية في طب الأسنان من جامعة لندن",
  },
  
];

export default data;