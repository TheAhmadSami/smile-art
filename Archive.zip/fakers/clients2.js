import assets from "@sa/assets";
const data = [
  {id: 1, Image: assets.fb1.src},
  {id: 2, Image: assets.fb2.src},
  {id: 3, Image: assets.fb3.src},
  {id: 4, Image: assets.fb4.src},
  {id: 5, Image: assets.fb5.src},
  {id: 6, Image: assets.fb6.src},
  {id: 7, Image: assets.fb7.src},
  {id: 8, Image: assets.fb8.src},
  {id: 9, Image: assets.fb9.src},
  {id: 10, Image: assets.fb10.src},
  {id: 11, Image: assets.fb11.src},
  {id: 12, Image: assets.fb12.src},
  {id: 13, Image: assets.fb13.src},
  {id: 14, Image: assets.fb14.src},
  {id: 15, Image: assets.fb15.src},

];

export default data;
