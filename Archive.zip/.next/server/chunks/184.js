exports.id = 184;
exports.ids = [184];
exports.modules = {

/***/ 2825:
/***/ ((module) => {

// Exports
module.exports = {
	"articleCard": "ArticleCard_articleCard__s_3Gk",
	"content": "ArticleCard_content__vTFKq",
	"fullContent": "ArticleCard_fullContent__ZAx1Q",
	"knowMore": "ArticleCard_knowMore__xY7iA",
	"closeService": "ArticleCard_closeService__08sZx"
};


/***/ }),

/***/ 8801:
/***/ ((module) => {

// Exports
module.exports = {
	"articlesDetails": "Articles_articlesDetails__GUh6O",
	"categoriesContainer": "Articles_categoriesContainer__zXVi9",
	"categoryCard": "Articles_categoryCard__G2y7B",
	"active": "Articles_active__SW1_I",
	"closeArticle": "Articles_closeArticle__vRDkI",
	"articleContent": "Articles_articleContent__99hSQ",
	"info": "Articles_info__GnvJV",
	"img": "Articles_img__O60nU",
	"title": "Articles_title___Pupk",
	"desc": "Articles_desc__fmCq_"
};


/***/ }),

/***/ 3418:
/***/ ((module) => {

// Exports
module.exports = {
	"ArticlesCategories": "ArticlesCategories_ArticlesCategories__wLLYm",
	"sectionTitle": "ArticlesCategories_sectionTitle__Wij0A",
	"categoryCard": "ArticlesCategories_categoryCard__1DlYs",
	"articleItem": "ArticlesCategories_articleItem__avIc_"
};


/***/ }),

/***/ 6386:
/***/ ((module) => {

// Exports
module.exports = {
	"team-card": "CustomCard_team-card__wl_mH",
	"img": "CustomCard_img__wf6E3",
	"title": "CustomCard_title__sYCrT",
	"desc": "CustomCard_desc__xhwrq",
	"knowMore": "CustomCard_knowMore__dE977"
};


/***/ }),

/***/ 217:
/***/ ((module) => {

// Exports
module.exports = {
	"gallery": "Gallery_gallery__U_cIL",
	"content": "Gallery_content__TxO_w",
	"albumTitle": "Gallery_albumTitle__vCNwH",
	"imagesContainer": "Gallery_imagesContainer__SR1s8"
};


/***/ }),

/***/ 7538:
/***/ ((module) => {

// Exports
module.exports = {
	"reviews": "Reviews_reviews__bqVML",
	"content": "Reviews_content__9vsAR"
};


/***/ }),

/***/ 4277:
/***/ ((module) => {

// Exports
module.exports = {
	"servicesDetails": "Services_servicesDetails__c4uu7",
	"closeService": "Services_closeService__Gvkdt",
	"serviceContent": "Services_serviceContent__bx5zA",
	"info": "Services_info__5ZjfI",
	"img": "Services_img__j7573",
	"title": "Services_title___Iz6n",
	"desc": "Services_desc__Zv6gx",
	"serviceImagesContainer": "Services_serviceImagesContainer__hyGKe"
};


/***/ }),

/***/ 6425:
/***/ ((module) => {

// Exports
module.exports = {
	"contacts": "SocialContacts_contacts__YbCJl",
	"item": "SocialContacts_item__Ybdms"
};


/***/ }),

/***/ 233:
/***/ ((module) => {

// Exports
module.exports = {
	"teamDetails": "Team_teamDetails__nFMiE"
};


/***/ }),

/***/ 1312:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ assets)
});

;// CONCATENATED MODULE: ./assets/images/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.994c6169.png","height":2201,"width":2573,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAuklEQVR42mOAgVNLvG0OLAzx370kqW/1jHhlkNjamXFMcAXL2qxnxAdolovwMMYDuSZQYSaGwwu8mUGsPbM83OY1WhsDmdYxvho8cJ2H57mDFTzdE2l0bWOEP5CZA5NbOiubEcYWm1Jpbt5daGIGZDsAsRIQ84Jlnqwx58wJlg6OcJGIjPNTjW7ItXHOT7KOm9YRbf7//1tWhmhnIb/8EGnn1AD5pNworZDcWOPwgiSbqNoi74DsFBdfAJaLNmB2Dd3qAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./assets/images/logo-light.png
/* harmony default export */ const logo_light = ({"src":"/_next/static/media/logo-light.868447a0.png","height":2201,"width":2573,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAAz0lEQVR42mP4//8/Awhf2ZRl8/DkDP83t7f2fX5+Rhkk9vHpCSYGmIJH59bP+PHlbfmfP3/igXwTIGb49/8/E8ONXfXMIM6dgxPdnl3bYwxkW//8+o4HppHh6tZysILjExmMLq3x8Qeyc2CSPz/fZYRZIfby9nHz1w/OmwHZDn///1cCYl6wCQsYGDjfPn8Q/OXDm8gvH99Ef3x1z/nb51dx3z/cN/92koGV4f2bV36vn9x3/vD6edKH109DPr9/Ef7lw8uob59eBHz/+t4XANuYn8OYcBWsAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./assets/images/image.png
/* harmony default export */ const images_image = ({"src":"/_next/static/media/image.d090c649.png","height":500,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAATlBMVEXi5unh5unh5ejf4+be4uXc4OPb3+LX293S1dfP0dPO0dPKzM7JzM3Iy8zHycvHycrHyMrGyMrExsfExcfDxMbBwsO9vr+3t7i0tLSzs7NBha4rAAAAP0lEQVR42jWLSQKAIBDD6rSjgrgr6v8/KhxIrgkkFiSQLhZh4cjPGw1dmr4rrwCWfbRhBiyeabuD1bh3J9H2H0YEAec1/H+rAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/images/facebook-logo-circle.png
/* harmony default export */ const facebook_logo_circle = ({"src":"/_next/static/media/facebook-logo-circle.0fc413d2.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA/ElEQVR42jWLvUoDQRhFb6E2QljEwiJYRMVNo2ivPoCIb2IREEUQQUQLtRHUwp+ojUHwIcZUomClKJqFTVzMmmwYyELmZ9kvM4FcOM05XGTuExjcbClhQ6VE4dpwodncQ+LCbvRKuGNFEQ0WJc3eifTxTdPNsyZcimj+VrhwTmM2fR4T9tuSfSiye3qXEicxjZ/FDM4hV9kjnuKAU+1fU+VPE3Y45Y55mjENub2mwnojff0S1N/LZ4esm7DN2ayz4Y06LeyG8jdUZJnZDuWAcSOmAWtBfrIQtLDs009V0Ldv3is+TRWCyDasbtUseSx5Za/a0RUDFr1yzwHoAqzApcdKFvzhAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/images/google-logo.png
/* harmony default export */ const google_logo = ({"src":"/_next/static/media/google-logo.8d9fbcdb.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA7ElEQVR42mMAgdehRmIvnUxXvHI2/fUSgte/dDZTBUveY3AWfWlpev+Vi8l/oKJtL1xs97xwsf7/zN3bFazg63y55W8SDP8/V7DyYMAGfu1j+vl7h+ABELu/54qQe8unraZt3/a7tnze69j6pYfh/x6Gn193S4IVVE+8LuLU+umMS8vnK46tn/87tXy5znBxq+HyglW+/xmWhrvDTHWu+2/i1Pz9v2PrpwkMDDMzxASXh9w3WxH033h5+DbjlQ6bzRd2/LfvefjYrfi/CFhHzEp/MaPlwStMVgT9Mlke+sd4pcUmnc0MMgwMDAwAlqJpxIVt0D4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./assets/images/article-header.jpg
/* harmony default export */ const article_header = ({"src":"/_next/static/media/article-header.004d6484.jpg","height":600,"width":900,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABgEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAKQEf//EABwQAAIBBQEAAAAAAAAAAAAAAAECBAAREhQhkf/aAAgBAQABPwCZJOszY3dGYAk88r//xAAWEQEBAQAAAAAAAAAAAAAAAAABADH/2gAIAQIBAT8Adb//xAAYEQACAwAAAAAAAAAAAAAAAAAAAQIRIf/aAAgBAwEBPwCGq2f/2Q==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./assets/index.jsx
/* eslint-disable import/no-anonymous-default-export */ 





/* harmony default export */ const assets = ({
    logo: logo,
    logoLight: logo_light,
    empty: images_image,
    facebookLogo: facebook_logo_circle,
    googleLogo: google_logo,
    articleHeader: article_header
});


/***/ }),

/***/ 8826:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1104);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__]);
([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//styles



const ArticleArea = ({ small  })=>{
    const [t] = useTranslation();
    const lang = useSelector((state)=>state.lang.value);
    return /*#__PURE__*/ _jsx("section", {
        id: "ArticleArea"
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ArticleArea)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 404:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _sa_styles_components_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2825);
/* harmony import */ var _sa_styles_components_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_components_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3759);
/* harmony import */ var react_quill_dist_quill_snow_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1791);
/* harmony import */ var react_quill_dist_quill_snow_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_quill_dist_quill_snow_css__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//styles




const ReactQuill =  false ? 0 : ()=>false;

const ArticleCard = ({ article  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.lang.value);
    const [modalStatus, setModalStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const modules = {
        toolbar: false,
        clipboard: {
            matchVisual: false
        }
    };
    const formats = [
        "header",
        "bold",
        "italic",
        "underline",
        "strike",
        "blockquote",
        "list",
        "bullet",
        "indent",
        "link",
        "image",
        "video",
        "align",
        "direction",
        "color"
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_sa_styles_components_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_7___default().articleCard),
        style: {
            marginBottom: "10px"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_sa_styles_components_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_7___default().title),
                children: lang == "en" ? article?.titleEn : article?.titleAr
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sa_styles_components_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_7___default().content),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ReactQuill, {
                    value: lang == "en" ? article?.contentEn : article?.contentAr,
                    readOnly: true,
                    modules: modules,
                    formats: formats
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: `${_sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__/* .domain */ .nw}/article/${article?.id}`,
                target: "_blank",
                rel: "noreferrer",
                className: (_sa_styles_components_ArticleCard_module_scss__WEBPACK_IMPORTED_MODULE_7___default().knowMore),
                children: t("know_more")
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArticleCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9347:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1104);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__]);
([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//styles




const ArticleHeader = ({ small , title , date  })=>{
    const [t] = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "article_header",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(___WEBPACK_IMPORTED_MODULE_2__/* .ArticleMenu */ .yw, {
                small: small
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "header-content",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "header-title",
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: moment__WEBPACK_IMPORTED_MODULE_5___default()(date).format("DD-MM-yyyy hh:mm A")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArticleHeader);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1349:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1104);
/* harmony import */ var _sa_assets__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1312);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _sa_utils_changeLanguage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(166);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3759);
/* harmony import */ var _sa_redux_reservation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9897);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_6__]);
([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable @next/next/no-img-element */ 


//styles







const ArticleMenu = ({ small  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.lang.value);
    const [scroll, setScroll] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [toggle, setToggle] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [menuItems, setMenuItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        {
            label: "home",
            href: `${_sa_utils_axios__WEBPACK_IMPORTED_MODULE_6__/* .domain */ .nw}/`
        },
        {
            label: "reviews",
            href: `${_sa_utils_axios__WEBPACK_IMPORTED_MODULE_6__/* .domain */ .nw}/#reviews`
        },
        {
            label: "team",
            href: `${_sa_utils_axios__WEBPACK_IMPORTED_MODULE_6__/* .domain */ .nw}/#team`
        },
        {
            label: "logo",
            href: "",
            isLogo: true
        },
        {
            label: "services",
            href: `${_sa_utils_axios__WEBPACK_IMPORTED_MODULE_6__/* .domain */ .nw}/#services`
        },
        {
            label: "gallery",
            href: `${_sa_utils_axios__WEBPACK_IMPORTED_MODULE_6__/* .domain */ .nw}/#gallery`
        },
        {
            label: "contact_us",
            href: "#contact"
        }
    ]);
    const handleScroll = (e)=>{
        if (e.target.documentElement.scrollTop > 150) {
            setScroll(true);
        } else {
            setScroll(false);
        }
    };
    const goTo = (itemId)=>{
        setToggle(false);
        location.href = itemId;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${small ? "menu scroll" : "menu"} ${toggle ? "active" : ""}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: "http://www.smileart-eg.com",
                className: "main-logo",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: _sa_assets__WEBPACK_IMPORTED_MODULE_3__/* ["default"].logo.src */ .Z.logo.src,
                    alt: ""
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "book-now",
                onClick: ()=>{
                    dispatch((0,_sa_redux_reservation__WEBPACK_IMPORTED_MODULE_7__/* .setReservation */ .R5)(true));
                },
                children: t("book_now")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "_menu_",
                children: [
                    menuItems.map((item, index)=>{
                        return item?.isLogo ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "menu-item logo",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "http://www.smileart-eg.com",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: _sa_assets__WEBPACK_IMPORTED_MODULE_3__/* ["default"].logo.src */ .Z.logo.src,
                                    alt: ""
                                })
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "menu-item",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                onClick: ()=>goTo(item?.href),
                                target: item?.isOut && "_blank",
                                rel: item?.isOut && "noreferrer",
                                children: t(item?.label)
                            })
                        }, index);
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "lang-toggle",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: lang == "en" && "active",
                                onClick: ()=>(0,_sa_utils_changeLanguage__WEBPACK_IMPORTED_MODULE_8__/* .changeLang */ .t)("en"),
                                children: "EN"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                style: {
                                    fontFamily: "Arial",
                                    fontSize: "16px"
                                },
                                className: lang == "ar" && "active",
                                onClick: ()=>(0,_sa_utils_changeLanguage__WEBPACK_IMPORTED_MODULE_8__/* .changeLang */ .t)("ar"),
                                children: "ع"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "menu-toggle",
                onClick: ()=>setToggle((old)=>!old),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArticleMenu);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 456:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3759);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _sa_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1104);
/* harmony import */ var _sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8801);
/* harmony import */ var _sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__, _sa_components__WEBPACK_IMPORTED_MODULE_7__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__, _sa_components__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// Import css files


//components

//styles



const Articles = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.lang.value);
    const [services, setServices] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [activeService, setActiveService] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [modalStatus, setModalStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [categories, setCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [articles, setArticles] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [categoryId, setCategoryId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const settings = {
        speed: 500,
        slidesToShow: 2
    };
    const mystyle = "linear-gradient(267.04deg, #5F818C, #98B8C0)";
    const getArticles = ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__/* .get */ .U2)("/article").then((res)=>{
            setArticles(res?.data);
        });
    };
    const getCategories = ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__/* .get */ .U2)("/category").then((res)=>{
            setCategories(res?.data);
        });
    };
    const getCategoryArticles = ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__/* .get */ .U2)(`/article/category/articles/${categoryId}`).then((res)=>{
            setArticles(res?.data);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (categoryId == 0) {
            getArticles();
        } else {
            getCategoryArticles();
        }
    }, [
        categoryId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getArticles();
        getCategories();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "articles",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "section-title light",
                children: t("articles")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().articlesDetails),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: `${(_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().categoryCard)} ${categoryId == 0 && (_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().active)}`,
                        onClick: ()=>setCategoryId(0),
                        children: lang == "ar" ? "جميع الأقسام" : "All Categories"
                    }),
                    categories?.length > 0 && categories?.map((category, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: (_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().categoryCard),
                            onClick: ()=>setCategoryId(category?.id),
                            children: lang == "ar" ? category?.nameAr : category?.nameEn
                        }, index);
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        id: "feeds",
                        children: articles?.length > 0 && articles?.map((article, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sa_components__WEBPACK_IMPORTED_MODULE_7__/* .ArticleCard */ .Tn, {
                                article: article
                            }, index);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Modal, {
                open: modalStatus,
                onClose: ()=>setModalStatus(false),
                "aria-labelledby": "modal-modal-title",
                "aria-describedby": "modal-modal-description",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "serviceModal",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().closeService),
                            onClick: ()=>setModalStatus(false),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "fas fa-times"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().serviceContent),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().img),
                                    style: {
                                        backgroundImage: `url(${activeService?.image})`
                                    }
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().info),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().title),
                                            children: lang == "en" ? activeService?.titleEn : activeService?.titleAr
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_sa_styles_components_Articles_module_scss__WEBPACK_IMPORTED_MODULE_9___default().desc),
                                            children: lang == "en" ? activeService?.subtitleEn : activeService?.subtitleAr
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sa_components__WEBPACK_IMPORTED_MODULE_7__/* .Gallery */ .ri, {})
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Articles);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2802:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1104);
/* harmony import */ var _sa_styles_components_ArticlesCategories_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3418);
/* harmony import */ var _sa_styles_components_ArticlesCategories_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_components_ArticlesCategories_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3759);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__]);
([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//styles





const ArticlesCategories = ({ onClick  })=>{
    const [t] = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const [categories, setCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.lang.value);
    const getCategories = ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__/* .get */ .U2)("/category").then((res)=>{
            setCategories(res?.data);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getCategories();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_sa_styles_components_ArticlesCategories_module_scss__WEBPACK_IMPORTED_MODULE_6___default().ArticlesCategories),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: (_sa_styles_components_ArticlesCategories_module_scss__WEBPACK_IMPORTED_MODULE_6___default().sectionTitle),
                children: lang == "ar" ? "الأقسام" : "Categories"
            }),
            categories?.length > 0 && categories?.map((category, index)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: (_sa_styles_components_ArticlesCategories_module_scss__WEBPACK_IMPORTED_MODULE_6___default().categoryCard),
                            onClick: onClick,
                            children: lang == "ar" ? category?.nameAr : category?.nameEn
                        }),
                        category?.articles?.map((article, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: `${_sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__/* .domain */ .nw}/article/${article?.id}`,
                                    className: (_sa_styles_components_ArticlesCategories_module_scss__WEBPACK_IMPORTED_MODULE_6___default().articleItem),
                                    children: lang == "ar" ? article?.titleAr : article?.titleEn
                                })
                            }, i))
                    ]
                }, index);
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArticlesCategories);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4136:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _sa_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1104);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _sa_components__WEBPACK_IMPORTED_MODULE_5__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _sa_components__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable @next/next/no-img-element */ 




//translation

//components

//styles

const Carousal = ({ children , swiperOptions  })=>{
    swiperOptions = swiperOptions ?? {
        spaceBetween: 5,
        navigation: true,
        pagination: {
            clickable: true
        },
        autoplay: true,
        breakpoints: {
            1500: {
                slidesPerView: 4
            },
            1250: {
                slidesPerView: 3
            },
            825: {
                slidesPerView: 2
            },
            480: {
                slidesPerView: 1
            },
            0: {
                slidesPerView: 1
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
        ...swiperOptions,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Carousal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 277:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_simple_image_slider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3103);
/* harmony import */ var react_simple_image_slider__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_simple_image_slider__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3759);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7987);
/* harmony import */ var _sa_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1104);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sa_utils_axios__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_8__, _sa_components__WEBPACK_IMPORTED_MODULE_9__]);
([_sa_utils_axios__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_8__, _sa_components__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable @next/next/no-img-element */ 





// Import css files


//translation

//components

//styles

const Gallery = ({ data , google  })=>{
    const { t  } = useTranslation();
    const [imageModal, setImageModal] = useState(false);
    const [image, setImage] = useState(0);
    const openModal = (index)=>{
        setImage(index);
        setImageModal(true);
    };
    const settings = {
        speed: 500,
        autoplay: true,
        infinite: false,
        slidesToShow: 6,
        slidesToScroll: 2
    };
    return /*#__PURE__*/ _jsxs("div", {
        id: styles.clients,
        className: "__page",
        children: [
            /*#__PURE__*/ _jsxs(Slider, {
                ...settings,
                className: "slider2222",
                children: [
                    data.length > 0 && data?.map((item, index)=>{
                        return /*#__PURE__*/ _jsx("img", {
                            src: item?.url,
                            className: styles.img,
                            alt: "Smile Art",
                            onClick: ()=>openModal(index)
                        }, index);
                    }),
                    /*#__PURE__*/ _jsx("a", {
                        className: styles.viewMore,
                        href: google ? "https://google.com/" : "https://fb.com/",
                        children: /*#__PURE__*/ _jsx("p", {
                            children: "View More"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ _jsx(Modal, {
                open: imageModal,
                onClose: ()=>setImageModal(false),
                "aria-labelledby": "modal-modal-title",
                "aria-describedby": "modal-modal-description",
                children: /*#__PURE__*/ _jsx("div", {
                    className: "imageSliderContainer",
                    children: /*#__PURE__*/ _jsx(SimpleImageSlider, {
                        width: 1920 / 2.5,
                        height: 1080 / 2.5,
                        images: data,
                        showBullets: true,
                        startIndex: image,
                        showNavs: true
                    })
                })
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Gallery)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6685:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3759);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, react_toastify__WEBPACK_IMPORTED_MODULE_5__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_10__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, react_toastify__WEBPACK_IMPORTED_MODULE_5__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








// Import css files



const Contacts = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.lang.value);
    //contact
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [phone, setPhone] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    //branches
    const [branches, setBranches] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [activeBranch, setActiveBranch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const notify = (message)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast)(message);
    const sendMessage = ()=>{
        let checker = true;
        if (!name) {
            notify(t("name_required"));
            checker = false;
            return;
        }
        if (!phone) {
            notify(t("phone_required"));
            checker = false;
            return;
        }
        if (!email) {
            notify(t("email_required"));
            checker = false;
            return;
        }
        if (!message) {
            notify(t("message_required"));
            checker = false;
            return;
        }
        if (checker) {
            let data = new FormData();
            data.append("name", name);
            data.append("phone", phone);
            data.append("fromEmail", email);
            data.append("message", message);
            setLoading(true);
            (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_10__/* .post */ .v_)("/contact", data).then((res)=>{
                setLoading(false);
                notify(t("email_sent_success"));
            }).catch((error)=>{
                setLoading(false);
                notify(t("email_sent_error"));
            });
        }
    };
    const loadBranches = ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_10__/* .get */ .U2)("/branches").then((res)=>{
            setBranches(res?.data);
            setActiveBranch(res?.data?.[0]);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loadBranches();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                id: "location",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                    src: activeBranch?.mapDisplayLink,
                    style: {
                        border: 0
                    },
                    allowFullScreen: true
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                id: "contact",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_5__.ToastContainer, {
                        position: lang == "ar" ? "bottom-right" : "bottom-right"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "contact-container",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "left-side",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "title",
                                        children: t("contact_us")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "branchesContainer",
                                        children: branches?.map((branch)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                onClick: ()=>setActiveBranch(branch),
                                                className: `branchCard ${activeBranch?.id == branch?.id && "active"}`,
                                                children: lang == "ar" ? branch?.nameAr : branch?.nameEn
                                            }, branch?.id))
                                    }),
                                    activeBranch && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "address",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fas fa-map-marker-alt"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                children: [
                                                                    lang == "ar" ? activeBranch?.nameAr : activeBranch?.nameEn,
                                                                    `: `
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                href: activeBranch?.mapLink,
                                                                target: "_blank",
                                                                rel: "noreferrer",
                                                                children: lang == "ar" ? activeBranch?.addressAr : activeBranch?.addressEn
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            activeBranch?.phone1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "phones",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fas fa-phone-alt"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: `tel: ${activeBranch?.phone1}`,
                                                            children: activeBranch?.phone1
                                                        })
                                                    })
                                                ]
                                            }),
                                            activeBranch?.phone2 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "phones",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fas fa-phone-alt"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: `tel: ${activeBranch?.phone2}`,
                                                            children: activeBranch?.phone1
                                                        })
                                                    })
                                                ]
                                            }),
                                            activeBranch?.phone3 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "phones",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fas fa-phone-alt"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: `tel: ${activeBranch?.phone3}`,
                                                            children: activeBranch?.phone1
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "address",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fas fa-clock"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                children: [
                                                                    t("workhours"),
                                                                    ": "
                                                                ]
                                                            }),
                                                            t("reach_us", {
                                                                fromDay: t(activeBranch?.fromDay),
                                                                toDay: t(activeBranch?.toDay),
                                                                fromTime: moment__WEBPACK_IMPORTED_MODULE_3___default()(activeBranch?.fromTime, [
                                                                    "hh:mm"
                                                                ]).format("hh:mmA"),
                                                                toTime: moment__WEBPACK_IMPORTED_MODULE_3___default()(activeBranch?.toTime, [
                                                                    "hh:mm"
                                                                ]).format("hh:mmA")
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "right-side",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "input-container",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: t("full_name")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                id: "contact_name",
                                                name: "name",
                                                type: "text",
                                                onChange: (e)=>{
                                                    setName(e.target.value);
                                                }
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "input-container",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: t("phone_number")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                id: "contact_phone",
                                                name: "phone",
                                                type: "number",
                                                onChange: (e)=>{
                                                    setPhone(e.target.value);
                                                }
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "input-container",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: t("email")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                id: "contact_email",
                                                name: "email",
                                                type: "email",
                                                onChange: (e)=>{
                                                    setEmail(e.target.value);
                                                }
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "input-container",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                children: t("message")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                name: "message",
                                                id: "contact_message",
                                                onChange: (e)=>setMessage(e.target.value)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "submit-message",
                                                onClick: sendMessage,
                                                children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_4__.TailSpin, {
                                                    height: "30",
                                                    width: "30",
                                                    color: "#b38f22",
                                                    ariaLabel: "tail-spin-loading",
                                                    radius: "1",
                                                    wrapperStyle: {},
                                                    wrapperClass: "",
                                                    visible: true
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "fas fa-paper-plane"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contacts);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4110:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _sa_styles_components_CustomCard_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6386);
/* harmony import */ var _sa_styles_components_CustomCard_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_components_CustomCard_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 



//styles


const CustomCard = ({ title , description , image , link , onClick , isService  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.lang.value);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_sa_styles_components_CustomCard_module_scss__WEBPACK_IMPORTED_MODULE_5___default()["team-card"]),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sa_styles_components_CustomCard_module_scss__WEBPACK_IMPORTED_MODULE_5___default().img),
                style: {
                    backgroundImage: `url(${image})`
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sa_styles_components_CustomCard_module_scss__WEBPACK_IMPORTED_MODULE_5___default().title),
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sa_styles_components_CustomCard_module_scss__WEBPACK_IMPORTED_MODULE_5___default().desc),
                children: description
            }),
            isService && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                onClick: onClick,
                className: (_sa_styles_components_CustomCard_module_scss__WEBPACK_IMPORTED_MODULE_5___default().knowMore),
                dir: lang == "en" ? "rtl" : "ltr",
                children: t("know_more")
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3056:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var react_facebook__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3266);
/* harmony import */ var react_facebook__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_facebook__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




//styles

const FacebookFeed = ()=>{
    const { t  } = useTranslation();
    return /*#__PURE__*/ _jsxs("div", {
        id: styles.facebookFeed,
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: styles.row,
                children: /*#__PURE__*/ _jsxs("div", {
                    className: styles.row2,
                    children: [
                        /*#__PURE__*/ _jsx("i", {
                            className: "fab fa-facebook"
                        }),
                        /*#__PURE__*/ _jsx("h1", {
                            className: styles.title,
                            children: t("facebook_feed")
                        })
                    ]
                })
            }),
            /*#__PURE__*/ _jsx(FacebookProvider, {
                appId: "843984503317267",
                children: /*#__PURE__*/ _jsx(Page, {
                    href: "https://www.facebook.com/SmileArtDrmagdy",
                    tabs: "timeline"
                })
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (FacebookFeed)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7127:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3759);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _sa_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1104);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__, _sa_components__WEBPACK_IMPORTED_MODULE_7__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__, _sa_components__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// Import css files


//components

//styles

const Footer = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "footer",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "copyrights",
                children: t("footer")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "developer",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        children: [
                            t("developed_by"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "fas fa-heart"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "http://linkedin.com/in/theahmadsami",
                        target: "_blank",
                        rel: "noreferrer",
                        style: {
                            color: "#fff",
                            textDecoration: "underline"
                        },
                        children: t("ahmed_sami")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1515:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_simple_image_slider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3103);
/* harmony import */ var react_simple_image_slider__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_simple_image_slider__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3759);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
/* harmony import */ var _sa_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1104);
/* harmony import */ var _sa_styles_components_Gallery_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(217);
/* harmony import */ var _sa_styles_components_Gallery_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_components_Gallery_module_scss__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__, _sa_components__WEBPACK_IMPORTED_MODULE_7__]);
([_sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_6__, _sa_components__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable @next/next/no-img-element */ 





//translation

//components

//styles

const Gallery = ({ hideTitle  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.lang.value);
    const [albums, setAlbums] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [imageModal, setImageModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [activeImages, setActiveImages] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [image, setImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const loadAlbums = async ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_5__/* .get */ .U2)("/albums").then((res)=>{
            setAlbums(res.data);
        });
    };
    const onImageChange = (event)=>{
        if (event.target.files && event.target.files[0]) {
            setImage(event.target.files[0]);
        }
    };
    const closeModal = ()=>{
        setImage(null);
        setModalStatus(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loadAlbums();
    }, []);
    const [windowWidth, setWindowWidth] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)( false ? 0 : 0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        function handleResize() {
            setWindowWidth(window.innerWidth);
        }
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "gallery",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "section-title light",
                children: t("gallery")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                id: (_sa_styles_components_Gallery_module_scss__WEBPACK_IMPORTED_MODULE_8___default().gallery),
                className: "__page",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sa_styles_components_Gallery_module_scss__WEBPACK_IMPORTED_MODULE_8___default().content),
                        children: albums.length > 0 && albums?.map((album, index)=>{
                            if (album?.images?.length > 0) {
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_sa_styles_components_Gallery_module_scss__WEBPACK_IMPORTED_MODULE_8___default().albumTitle),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: lang == "en" ? album?.nameEn : album?.nameAr
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: t("view_more")
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_sa_styles_components_Gallery_module_scss__WEBPACK_IMPORTED_MODULE_8___default().imagesContainer),
                                            children: album?.images?.length > 0 && album?.images?.map((image)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: image?.url,
                                                    className: (_sa_styles_components_Gallery_module_scss__WEBPACK_IMPORTED_MODULE_8___default().img),
                                                    alt: "Smile Art",
                                                    onClick: ()=>{
                                                        setActiveImages(album?.images);
                                                        setTimeout(()=>{
                                                            setImageModal(true);
                                                        }, 300);
                                                    }
                                                }, index))
                                        })
                                    ]
                                }, index);
                            }
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Modal, {
                        open: imageModal,
                        onClose: ()=>setImageModal(false),
                        "aria-labelledby": "modal-modal-title",
                        "aria-describedby": "modal-modal-description",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "imageSliderContainer",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_simple_image_slider__WEBPACK_IMPORTED_MODULE_3___default()), {
                                width: windowWidth > 500 ? 500 : windowWidth,
                                height: windowWidth > 500 ? 500 : windowWidth,
                                images: activeImages,
                                showBullets: true,
                                showNavs: true
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Gallery);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6375:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1104);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__]);
([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



//styles



const Header = ({ small  })=>{
    const [t] = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.lang.value);
    const configs = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.configs.value);
    const [drMagdy, showDrMagdy] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "header",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(___WEBPACK_IMPORTED_MODULE_2__/* .Menu */ .v2, {
                small: small
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "header-content",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "header-title",
                        children: lang == "ar" ? configs?.titleAr : configs?.titleEn
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "header-desc",
                        children: lang == "en" ? configs?.aboutEn : configs?.aboutAr
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "header-buttons",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: "#contact",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "fas fa-info-circle"
                                    }),
                                    " ",
                                    t("contact_us")
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                onClick: ()=>showDrMagdy(true),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "fas fa-user-tie"
                                    }),
                                    t("about_dr_magdy")
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "ceo-voice",
                className: `_ceo-voice_ ${drMagdy && "active"}`,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "_ceo-voice_",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "close",
                            onClick: ()=>showDrMagdy(false),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "fas fa-times"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "image",
                            style: {
                                backgroundImage: "url(dr-magdy.jpeg)"
                            }
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text",
                            dir: lang == "ar" ? "rtl" : "ltr",
                            children: [
                                lang == "ar" ? configs?.wordAr : configs?.wordEn,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: t("dr_magdy")
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "header-video",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                        className: "sample-video",
                        src: "videos/video.mp4",
                        muted: true,
                        loop: true,
                        autoPlay: true
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "original-video",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            id: "player"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                id: "play_video",
                href: configs?.youtubeVideo,
                target: "_blank",
                rel: "noreferrer",
                dir: lang == "en" ? "ltr" : "rtl",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "fas fa-play"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "close_video",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "fas fa-times"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 627:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



//styles

const InstagramFeed = ()=>{
    const { t  } = useTranslation();
    return /*#__PURE__*/ _jsxs("div", {
        id: styles.instagramFeed,
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: styles.row,
                children: /*#__PURE__*/ _jsxs("div", {
                    className: styles.row2,
                    children: [
                        /*#__PURE__*/ _jsx("i", {
                            className: "fab fa-instagram"
                        }),
                        /*#__PURE__*/ _jsx("h1", {
                            className: styles.title,
                            children: t("instagram_feed")
                        })
                    ]
                })
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "data-load-issue-container",
                children: /*#__PURE__*/ _jsx("p", {
                    className: "data-load-issue",
                    children: t("data_load_issue")
                })
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (InstagramFeed)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7675:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1104);
/* harmony import */ var _sa_assets__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1312);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _sa_utils_changeLanguage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(166);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _sa_redux_reservation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9897);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
([___WEBPACK_IMPORTED_MODULE_2__, react_i18next__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable @next/next/no-img-element */ 


//styles






const Menu = ({ small  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.lang.value);
    const [scroll, setScroll] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const [toggle, setToggle] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [menuItems, setMenuItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        {
            label: "home",
            href: "#header"
        },
        {
            label: "services",
            href: "#services"
        },
        {
            label: "articles",
            href: "#articles"
        },
        {
            label: "team",
            href: "#team"
        },
        {
            label: "logo",
            href: "",
            isLogo: true
        },
        {
            label: "gallery",
            href: "#gallery"
        },
        {
            label: "reviews",
            href: "#reviews"
        },
        {
            label: "contact_us",
            href: "#contact"
        }
    ]);
    const handleScroll = (e)=>{
        if (e.target.documentElement.scrollTop > 150) {
            setScroll(true);
        } else {
            setScroll(false);
        }
    };
    const goTo = (itemId)=>{
        setToggle(false);
        location.href = itemId;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${small ? "menu scroll" : "menu"} ${toggle ? "active" : ""}`,
        style: lang == "ar" ? {
            paddingRight: "0px"
        } : {
            paddingLeft: "0px"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: "http://www.smileart-eg.com",
                className: "main-logo",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: _sa_assets__WEBPACK_IMPORTED_MODULE_3__/* ["default"].logo.src */ .Z.logo.src,
                    alt: ""
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "book-now",
                onClick: ()=>{
                    dispatch((0,_sa_redux_reservation__WEBPACK_IMPORTED_MODULE_6__/* .setReservation */ .R5)(true));
                },
                children: t("book_now")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "_menu_",
                children: [
                    menuItems.map((item, index)=>{
                        return item?.isLogo ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "menu-item logo",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "http://www.smileart-eg.com",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: _sa_assets__WEBPACK_IMPORTED_MODULE_3__/* ["default"].logo.src */ .Z.logo.src,
                                    alt: ""
                                })
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "menu-item",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                onClick: ()=>goTo(item?.href),
                                target: item?.isOut && "_blank",
                                rel: item?.isOut && "noreferrer",
                                children: t(item?.label)
                            })
                        }, index);
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "lang-toggle",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: lang == "en" && "active",
                                onClick: ()=>(0,_sa_utils_changeLanguage__WEBPACK_IMPORTED_MODULE_7__/* .changeLang */ .t)("en"),
                                children: "EN"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                style: {
                                    fontFamily: "Arial",
                                    fontSize: "16px"
                                },
                                className: lang == "ar" && "active",
                                onClick: ()=>(0,_sa_utils_changeLanguage__WEBPACK_IMPORTED_MODULE_7__/* .changeLang */ .t)("ar"),
                                children: "ع"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "menu-toggle",
                onClick: ()=>setToggle((old)=>!old),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3547:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3759);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _sa_redux_reservation__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9897);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, react_toastify__WEBPACK_IMPORTED_MODULE_6__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_9__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, react_toastify__WEBPACK_IMPORTED_MODULE_6__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










// Import css files




const Reservation = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    const configs = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.configs.value);
    const reservationStatus = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state?.reservation?.value);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useSelector)((state)=>state.lang.value);
    const [services, setServices] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [serviceId, setServiceId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [reservationDate, setReservationDate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(new Date());
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [phone, setPhone] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const notify = (message)=>(0,react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast)(message);
    const sendMessage = ()=>{
        let checker = true;
        if (!name) {
            notify(t("name_required"));
            checker = false;
            return;
        }
        if (!phone) {
            notify(t("phone_required"));
            checker = false;
            return;
        }
        if (!email) {
            notify(t("email_required"));
            checker = false;
            return;
        }
        if (checker) {
            let data = new FormData();
            data.append("name", name);
            data.append("phone", phone);
            data.append("fromEmail", email);
            data.append("reservationDate", reservationDate);
            data.append("service", JSON.stringify(services?.filter((service)=>service?.id == serviceId)?.[0]));
            setLoading(true);
            (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_9__/* .post */ .v_)("/booking", data).then((res)=>{
                dispatch((0,_sa_redux_reservation__WEBPACK_IMPORTED_MODULE_12__/* .setReservation */ .R5)(true));
                setLoading(false);
                notify(t("email_sent_success"));
            }).catch((error)=>{
                dispatch((0,_sa_redux_reservation__WEBPACK_IMPORTED_MODULE_12__/* .setReservation */ .R5)(true));
                setLoading(false);
                notify(t("email_sent_error"));
            });
        }
    };
    const loadServices = ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_9__/* .get */ .U2)("/services").then((res)=>{
            setServiceId(res.data?.[0]?.id);
            setServices(res.data);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loadServices();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        console.log("configs=-=-=-", configs);
    }, [
        configs
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `reservationContainer ${reservationStatus ? "active" : null}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            id: "reservation",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, {
                    position: lang == "ar" ? "bottom-right" : "bottom-right"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "reservation-container",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "closeBooking",
                            onClick: ()=>dispatch((0,_sa_redux_reservation__WEBPACK_IMPORTED_MODULE_12__/* .setReservation */ .R5)(false)),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "fas fa-times"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "left-side",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "title",
                                    children: t("book_now")
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "address",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fas fa-map-marker-alt"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        t("headquarter"),
                                                        ":"
                                                    ]
                                                }),
                                                t("address")
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "phones",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fas fa-phone"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: `tel: ${configs?.phone}`,
                                                    children: configs?.phone
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                configs?.phone != configs?.mobile && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: `tel: ${configs?.mobile}`,
                                                    children: configs?.mobile
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "note",
                                    children: t("reach_us", {
                                        fromDay: t(configs?.fromDay),
                                        toDay: t(configs?.toDay),
                                        fromTime: moment__WEBPACK_IMPORTED_MODULE_3___default()(configs?.fromTime, [
                                            "hh:mm"
                                        ]).format("hh:mmA"),
                                        toTime: moment__WEBPACK_IMPORTED_MODULE_3___default()(configs?.toTime, [
                                            "hh:mm"
                                        ]).format("hh:mmA")
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "right-side",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "input-container",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: t("full_name")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            id: "contact_name",
                                            name: "name",
                                            type: "text",
                                            onChange: (e)=>{
                                                setName(e.target.value);
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "input-container",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: t("phone_number")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            id: "contact_phone",
                                            name: "phone",
                                            type: "number",
                                            onChange: (e)=>{
                                                setPhone(e.target.value);
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "input-container",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: t("email")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            id: "contact_email",
                                            name: "email",
                                            type: "email",
                                            onChange: (e)=>{
                                                setEmail(e.target.value);
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "input-container",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: t("date")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            id: "contact_email",
                                            name: "date",
                                            type: "date",
                                            onChange: (e)=>{
                                                setReservationDate(e.target.value);
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "input-container",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            children: t("service")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                            onChange: (e)=>setServiceId(e?.target?.value),
                                            children: services?.map((service, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                    value: service?.id,
                                                    children: lang == "ar" ? service?.titleAr : service?.titleEn
                                                }, index))
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "buttonContainer",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "submit-message",
                                        style: lang == "ar" ? {
                                            right: "initial",
                                            left: "0px"
                                        } : {
                                            right: "10px",
                                            left: "initial"
                                        },
                                        onClick: sendMessage,
                                        children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_4__.TailSpin, {
                                            height: "30",
                                            width: "30",
                                            color: "#b38f22",
                                            ariaLabel: "tail-spin-loading",
                                            radius: "1",
                                            wrapperStyle: {},
                                            wrapperClass: "",
                                            visible: true
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fas fa-paper-plane"
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Reservation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 283:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3759);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3015);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _sa_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1104);
/* harmony import */ var _sa_styles_components_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7538);
/* harmony import */ var _sa_styles_components_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_components_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sa_utils_axios__WEBPACK_IMPORTED_MODULE_2__, swiper_react__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _sa_components__WEBPACK_IMPORTED_MODULE_5__]);
([_sa_utils_axios__WEBPACK_IMPORTED_MODULE_2__, swiper_react__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_4__, _sa_components__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable @next/next/no-img-element */ 



//translation

//components

//styles

const Reviews = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const [reviews, setReviews] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [imageModal, setImageModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [image, setImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const loadReviews = async ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_2__/* .get */ .U2)("/reviews").then((res)=>{
            setReviews(res.data);
        });
    };
    const onImageChange = (event)=>{
        if (event.target.files && event.target.files[0]) {
            setImage(event.target.files[0]);
        }
    };
    const closeModal = ()=>{
        setImage(null);
        setModalStatus(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loadReviews();
    }, []);
    const [windowWidth, setWindowWidth] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)( false ? 0 : 0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        function handleResize() {
            setWindowWidth(window.innerWidth);
        }
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "reviews",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "section-title light",
                children: t("reviews")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "clients-container"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                id: (_sa_styles_components_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().reviews),
                className: "__page",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sa_styles_components_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().content),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sa_components__WEBPACK_IMPORTED_MODULE_5__/* .Carousal */ .he, {
                            children: reviews.length > 0 && reviews?.map((item, index)=>{
                                return item.type == "image" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: `${_sa_utils_axios__WEBPACK_IMPORTED_MODULE_2__/* .mediaLink */ .hp}/reviews/${item?.url}`,
                                        className: (_sa_styles_components_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().img),
                                        alt: "Smile Art",
                                        onClick: ()=>setImageModal(true)
                                    })
                                }, index);
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_sa_styles_components_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().content),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sa_components__WEBPACK_IMPORTED_MODULE_5__/* .Carousal */ .he, {
                            children: reviews.length > 0 && reviews?.map((item, index)=>{
                                return item.type == "video" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_sa_styles_components_Reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().video),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                                            src: item?.url,
                                            frameborder: "0",
                                            allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
                                            allowfullscreen: true
                                        })
                                    })
                                }, index);
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Reviews);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1091:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3759);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_compare_slider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8181);
/* harmony import */ var react_compare_slider__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_compare_slider__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _sa_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1104);
/* harmony import */ var _sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4277);
/* harmony import */ var _sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__, _sa_components__WEBPACK_IMPORTED_MODULE_9__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__, _sa_components__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







// Import css files


//components

//styles


const Services = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const [services, setServices] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [activeService, setActiveService] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [modalStatus, setModalStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useSelector)((state)=>state.lang.value);
    const settings = {
        speed: 500,
        slidesToShow: 2
    };
    const mystyle = "linear-gradient(267.04deg, #5F818C, #98B8C0)";
    const loadServices = ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__/* .get */ .U2)("/services").then((res)=>{
            setServices(res.data);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loadServices();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "services",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "section-title light",
                children: t("services")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11___default().servicesDetails),
                children: services.length > 0 && services?.map((service, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sa_components__WEBPACK_IMPORTED_MODULE_9__/* .CustomCard */ ._t, {
                        isService: true,
                        image: service?.image,
                        title: lang == "en" ? service?.titleEn : service?.titleAr,
                        description: lang == "en" ? service?.subtitleEn : service?.subtitleAr,
                        link: service?.link,
                        onClick: ()=>{
                            setActiveService(service);
                            setModalStatus(true);
                        }
                    }, index);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Modal, {
                open: modalStatus,
                onClose: ()=>setModalStatus(false),
                "aria-labelledby": "modal-modal-title",
                "aria-describedby": "modal-modal-description",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "serviceModal",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11___default().closeService),
                            onClick: ()=>setModalStatus(false),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "fas fa-times"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11___default().serviceContent),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11___default().img),
                                    style: {
                                        backgroundImage: `url(${activeService?.image})`
                                    }
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11___default().info),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11___default().title),
                                            children: lang == "en" ? activeService?.titleEn : activeService?.titleAr
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11___default().desc),
                                            children: lang == "en" ? activeService?.subtitleEn : activeService?.subtitleAr
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_sa_styles_components_Services_module_scss__WEBPACK_IMPORTED_MODULE_11___default().serviceImagesContainer),
                            children: activeService?.serviceImages?.length > 0 && activeService?.serviceImages?.map((image, index)=>{
                                return image?.image1 && image?.image2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "compare-card",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_compare_slider__WEBPACK_IMPORTED_MODULE_6__.ReactCompareSlider, {
                                        itemOne: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_compare_slider__WEBPACK_IMPORTED_MODULE_6__.ReactCompareSliderImage, {
                                            src: image?.image1,
                                            alt: "Image one"
                                        }),
                                        itemTwo: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_compare_slider__WEBPACK_IMPORTED_MODULE_6__.ReactCompareSliderImage, {
                                            src: image?.image2,
                                            alt: "Image two"
                                        })
                                    })
                                });
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Services);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4751:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _sa_styles_components_SocialContacts_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6425);
/* harmony import */ var _sa_styles_components_SocialContacts_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_components_SocialContacts_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 

//translation

//styles


const SocialContacts = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const configs = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.configs.value);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.lang.value);
    const social = [
        {
            icon: "fab fa-facebook-f",
            href: configs?.facebook,
            color: "#1877f2"
        },
        {
            icon: "fab fa-instagram",
            href: configs?.instagram,
            color: "#8a3ab9"
        },
        {
            icon: "fab fa-youtube",
            href: configs?.youtube,
            color: "#ff0000"
        },
        {
            icon: "fab fa-tiktok",
            href: configs?.tiktok,
            color: "#000000"
        },
        {
            icon: "fab fa-snapchat",
            href: configs?.snapchat,
            color: "#fffc00",
            frontColor: "#000"
        },
        {
            icon: "fab fa-twitter",
            href: configs?.twitter,
            color: "#1DA1F2"
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        id: (_sa_styles_components_SocialContacts_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contacts),
        dir: lang == "en" ? "ltr" : "rtl",
        children: social.map((item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: item?.href,
                className: (_sa_styles_components_SocialContacts_module_scss__WEBPACK_IMPORTED_MODULE_4___default().item),
                style: {
                    color: item?.frontColor,
                    backgroundColor: item?.color
                },
                target: "_blank",
                rel: "noreferrer",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: item?.icon
                })
            }, i))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SocialContacts);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2104:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3759);
/* harmony import */ var _sa_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1104);
/* harmony import */ var _sa_styles_components_Team_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(233);
/* harmony import */ var _sa_styles_components_Team_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_components_Team_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _sa_assets__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1312);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__, _sa_components__WEBPACK_IMPORTED_MODULE_4__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__, _sa_components__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




//components

//styles



const Team = ()=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const [staff, setStaff] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const lang = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.lang.value);
    const mystyle = "linear-gradient(267.04deg, #5F818C, #98B8C0)";
    const loadStaff = ()=>{
        (0,_sa_utils_axios__WEBPACK_IMPORTED_MODULE_3__/* .get */ .U2)("/staff").then((res)=>{
            setStaff(res.data);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loadStaff();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "team",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "section-title light",
                children: t("team")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: (_sa_styles_components_Team_module_scss__WEBPACK_IMPORTED_MODULE_7___default().team),
                className: "__page",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_sa_styles_components_Team_module_scss__WEBPACK_IMPORTED_MODULE_7___default().teamDetails),
                    children: staff.length > 0 && staff?.map((team, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sa_components__WEBPACK_IMPORTED_MODULE_4__/* .CustomCard */ ._t, {
                            title: lang == "en" ? team?.titleEn : team?.titleAr,
                            description: lang == "en" ? team?.subtitleEn : team?.subtitleAr,
                            image: team?.image
                        }, index);
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Team);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3507:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 



//styles


const UserCard = ({ image  })=>{
    return /*#__PURE__*/ _jsx("div", {
        className: styles["team-card"],
        children: /*#__PURE__*/ _jsx("img", {
            src: image,
            className: styles.img,
            alt: "Smile Art"
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (UserCard)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1104:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$_": () => (/* reexport safe */ _Footer__WEBPACK_IMPORTED_MODULE_10__.Z),
/* harmony export */   "Fi": () => (/* reexport safe */ _ArticlesCategories__WEBPACK_IMPORTED_MODULE_18__.Z),
/* harmony export */   "K3": () => (/* reexport safe */ _ArticleHeader__WEBPACK_IMPORTED_MODULE_17__.Z),
/* harmony export */   "K9": () => (/* reexport safe */ _Services__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "P7": () => (/* reexport safe */ _SocialContacts__WEBPACK_IMPORTED_MODULE_9__.Z),
/* harmony export */   "SZ": () => (/* reexport safe */ _Team__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "Tn": () => (/* reexport safe */ _ArticleCard__WEBPACK_IMPORTED_MODULE_14__.Z),
/* harmony export */   "ZJ": () => (/* reexport safe */ _Articles__WEBPACK_IMPORTED_MODULE_15__.Z),
/* harmony export */   "Zv": () => (/* reexport safe */ _Reviews__WEBPACK_IMPORTED_MODULE_12__.Z),
/* harmony export */   "_t": () => (/* reexport safe */ _CustomCard__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "fe": () => (/* reexport safe */ _Reservation__WEBPACK_IMPORTED_MODULE_21__.Z),
/* harmony export */   "h4": () => (/* reexport safe */ _Header__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "he": () => (/* reexport safe */ _Carousal__WEBPACK_IMPORTED_MODULE_20__.Z),
/* harmony export */   "r8": () => (/* reexport safe */ _Contact__WEBPACK_IMPORTED_MODULE_11__.Z),
/* harmony export */   "ri": () => (/* reexport safe */ _Gallery__WEBPACK_IMPORTED_MODULE_7__.Z),
/* harmony export */   "v2": () => (/* reexport safe */ _Menu__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "yw": () => (/* reexport safe */ _ArticleMenu__WEBPACK_IMPORTED_MODULE_19__.Z)
/* harmony export */ });
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6375);
/* harmony import */ var _FacebookFeed__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3056);
/* harmony import */ var _InstagramFeed__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(627);
/* harmony import */ var _Menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7675);
/* harmony import */ var _Services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1091);
/* harmony import */ var _CustomCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4110);
/* harmony import */ var _Team__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2104);
/* harmony import */ var _Gallery__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1515);
/* harmony import */ var _Clients__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(277);
/* harmony import */ var _SocialContacts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4751);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7127);
/* harmony import */ var _Contact__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6685);
/* harmony import */ var _Reviews__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(283);
/* harmony import */ var _UserCard__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3507);
/* harmony import */ var _ArticleCard__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(404);
/* harmony import */ var _Articles__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(456);
/* harmony import */ var _ArticleArea__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8826);
/* harmony import */ var _ArticleHeader__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9347);
/* harmony import */ var _ArticlesCategories__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2802);
/* harmony import */ var _ArticleMenu__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1349);
/* harmony import */ var _Carousal__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4136);
/* harmony import */ var _Reservation__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(3547);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Header__WEBPACK_IMPORTED_MODULE_0__, _FacebookFeed__WEBPACK_IMPORTED_MODULE_1__, _InstagramFeed__WEBPACK_IMPORTED_MODULE_2__, _Menu__WEBPACK_IMPORTED_MODULE_3__, _Services__WEBPACK_IMPORTED_MODULE_4__, _CustomCard__WEBPACK_IMPORTED_MODULE_5__, _Team__WEBPACK_IMPORTED_MODULE_6__, _Gallery__WEBPACK_IMPORTED_MODULE_7__, _Clients__WEBPACK_IMPORTED_MODULE_8__, _SocialContacts__WEBPACK_IMPORTED_MODULE_9__, _Footer__WEBPACK_IMPORTED_MODULE_10__, _Contact__WEBPACK_IMPORTED_MODULE_11__, _Reviews__WEBPACK_IMPORTED_MODULE_12__, _UserCard__WEBPACK_IMPORTED_MODULE_13__, _ArticleCard__WEBPACK_IMPORTED_MODULE_14__, _Articles__WEBPACK_IMPORTED_MODULE_15__, _ArticleArea__WEBPACK_IMPORTED_MODULE_16__, _ArticleHeader__WEBPACK_IMPORTED_MODULE_17__, _ArticlesCategories__WEBPACK_IMPORTED_MODULE_18__, _ArticleMenu__WEBPACK_IMPORTED_MODULE_19__, _Carousal__WEBPACK_IMPORTED_MODULE_20__, _Reservation__WEBPACK_IMPORTED_MODULE_21__]);
([_Header__WEBPACK_IMPORTED_MODULE_0__, _FacebookFeed__WEBPACK_IMPORTED_MODULE_1__, _InstagramFeed__WEBPACK_IMPORTED_MODULE_2__, _Menu__WEBPACK_IMPORTED_MODULE_3__, _Services__WEBPACK_IMPORTED_MODULE_4__, _CustomCard__WEBPACK_IMPORTED_MODULE_5__, _Team__WEBPACK_IMPORTED_MODULE_6__, _Gallery__WEBPACK_IMPORTED_MODULE_7__, _Clients__WEBPACK_IMPORTED_MODULE_8__, _SocialContacts__WEBPACK_IMPORTED_MODULE_9__, _Footer__WEBPACK_IMPORTED_MODULE_10__, _Contact__WEBPACK_IMPORTED_MODULE_11__, _Reviews__WEBPACK_IMPORTED_MODULE_12__, _UserCard__WEBPACK_IMPORTED_MODULE_13__, _ArticleCard__WEBPACK_IMPORTED_MODULE_14__, _Articles__WEBPACK_IMPORTED_MODULE_15__, _ArticleArea__WEBPACK_IMPORTED_MODULE_16__, _ArticleHeader__WEBPACK_IMPORTED_MODULE_17__, _ArticlesCategories__WEBPACK_IMPORTED_MODULE_18__, _ArticleMenu__WEBPACK_IMPORTED_MODULE_19__, _Carousal__WEBPACK_IMPORTED_MODULE_20__, _Reservation__WEBPACK_IMPORTED_MODULE_21__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);























__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "q6": () => (/* binding */ setConfigs)
/* harmony export */ });
/* unused harmony export configsSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    value: {}
};
const configsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "configs",
    initialState,
    reducers: {
        setConfigs: (state, configs)=>{
            state.value = configs.payload;
        }
    }
});
const { setConfigs  } = configsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (configsSlice.reducer);


/***/ }),

/***/ 124:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Wg": () => (/* binding */ setLang),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export langSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    value: "en"
};
const langSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "lang",
    initialState,
    reducers: {
        setLang: (state, lang)=>{
            state.value = lang.payload;
        }
    }
});
const { setLang  } = langSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (langSlice.reducer);


/***/ }),

/***/ 9897:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R5": () => (/* binding */ setReservation),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export reservationSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    value: false
};
const reservationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "reservation",
    initialState,
    reducers: {
        setReservation: (state, action)=>{
            state.value = action.payload;
        }
    }
});
const { setReservation  } = reservationSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (reservationSlice.reducer);


/***/ }),

/***/ 3759:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U2": () => (/* binding */ get),
/* harmony export */   "hp": () => (/* binding */ mediaLink),
/* harmony export */   "nw": () => (/* binding */ domain),
/* harmony export */   "v_": () => (/* binding */ post)
/* harmony export */ });
/* unused harmony exports apiLink, put, remove */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

let domain = "http://localhost:3000";
let mediaLink = "http://localhost:3500/media";
let apiLink = "http://localhost:3500/v1";
domain = "https://smileart-eg.com";
mediaLink = "http://api.smileart-eg.com/v1/media";
apiLink = "https://api.smileart-eg.com/v1";
const post = async (url, data = new FormData())=>{
    // let token = await getData('user_t');
    // token && data.append('token', token);
    return await (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])({
        method: "POST",
        url: apiLink + url,
        data: data,
        validateStatus: ()=>true,
        headers: {
            Accept: "application/json, text/plain, /",
            "Content-Type": "multipart/form-data"
        }
    }).then((response)=>{
        return response;
    }).catch((error)=>{
        return error;
    });
};
const put = async (url, data = new FormData())=>{
    // let token = await getData('user_t');
    // token && data.append('token', token);
    return await axios({
        method: "PUT",
        url: apiLink + url,
        data: data,
        validateStatus: ()=>true,
        headers: {
            Accept: "application/json, text/plain, /",
            "Content-Type": "multipart/form-data"
        }
    }).then((response)=>{
        return response;
    }).catch((error)=>{
        console.log(error);
    });
};
const get = async (url, params = {})=>{
    // let token = await getData('user_t');
    // token && (params.token = token);
    return await (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])({
        method: "GET",
        url: apiLink + url,
        params: params,
        validateStatus: ()=>true
    }).then((response)=>{
        return response;
    }).catch((error)=>{
        console.log(error);
    });
};
const remove = async (url, params = {})=>{
    // let token = await getData('user_t');
    // token && data.append('token', token);
    return await axios({
        method: "DELETE",
        url: apiLink + url,
        params: params,
        validateStatus: ()=>true
    }).then((response)=>{
        return response;
    }).catch((error)=>{
        console.log(error);
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 166:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ changeLang)
/* harmony export */ });
const changeLang = (lang)=>{
    localStorage.setItem("lang", lang);
    window.location.reload();
};


/***/ })

};
;