(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4962:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2021);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var i18next_browser_languagedetector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6252);
/* harmony import */ var _locales_en__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9748);
/* harmony import */ var _locales_ar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9104);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__, i18next_browser_languagedetector__WEBPACK_IMPORTED_MODULE_2__]);
([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__, i18next_browser_languagedetector__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const resources = {
    en: {
        translation: _locales_en__WEBPACK_IMPORTED_MODULE_3__
    },
    ar: {
        translation: _locales_ar__WEBPACK_IMPORTED_MODULE_4__
    }
};
i18next__WEBPACK_IMPORTED_MODULE_0__["default"].use(i18next_browser_languagedetector__WEBPACK_IMPORTED_MODULE_2__["default"]).use(react_i18next__WEBPACK_IMPORTED_MODULE_1__.initReactI18next).init({
    resources,
    lng: "en",
    interpolation: {
        escapeValue: false
    },
    react: {
        useSuspense: false
    }
});
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (i18n)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3675:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _sa_styles_globals_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3716);
/* harmony import */ var _sa_styles_globals_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sa_styles_globals_scss__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sa_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4962);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _sa_redux_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5495);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _sa_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1104);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sa_i18n__WEBPACK_IMPORTED_MODULE_2__, _sa_components__WEBPACK_IMPORTED_MODULE_6__]);
([_sa_i18n__WEBPACK_IMPORTED_MODULE_2__, _sa_components__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const App = ({ Component , pageProps  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_redux__WEBPACK_IMPORTED_MODULE_3__.Provider, {
        store: _sa_redux_store__WEBPACK_IMPORTED_MODULE_4__/* .store */ .h,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_5___default()), {
                src: "https://www.googletagmanager.com/gtag/js?id=G-NBJ2R5NJFQ",
                strategy: "afterInteractive"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_5___default()), {
                id: "google-analytics",
                strategy: "afterInteractive",
                children: `
          window.dataLayer = window.dataLayer || [];
          function gtag(){window.dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'G-NBJ2R5NJFQ');
        `
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sa_components__WEBPACK_IMPORTED_MODULE_6__/* .Reservation */ .fe, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ store)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lang__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(124);
/* harmony import */ var _configs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2656);
/* harmony import */ var _reservation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9897);




const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        lang: _lang__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP,
        configs: _configs__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
        reservation: _reservation__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP
    }
});


/***/ }),

/***/ 3716:
/***/ (() => {



/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2245:
/***/ ((module) => {

"use strict";
module.exports = require("moment");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 8181:
/***/ ((module) => {

"use strict";
module.exports = require("react-compare-slider");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 3266:
/***/ ((module) => {

"use strict";
module.exports = require("react-facebook");

/***/ }),

/***/ 1223:
/***/ ((module) => {

"use strict";
module.exports = require("react-loader-spinner");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 3103:
/***/ ((module) => {

"use strict";
module.exports = require("react-simple-image-slider");

/***/ }),

/***/ 8096:
/***/ ((module) => {

"use strict";
module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 6252:
/***/ ((module) => {

"use strict";
module.exports = import("i18next-browser-languagedetector");;

/***/ }),

/***/ 7987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ }),

/***/ 9104:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"about_dr_magdy":"من هو الدكتور مجدي","address":"92 شارع سيد زكريا ، شيراتون ، القاهرة ، مصر.","ahmed_sami":"احمد سامي","book_now":"احجز الآن","call_us":"اتصل بنا","clients":"آراء العملاء","contact_us":"تواصل معنا","data_load_issue":"لا توجد بيانات لإظهارها الآن","developed_by":"تم التطوير من قبل","dr_magdy":"د. مجدي الغامري","email":"الايميل","facebook_feed":"فيسبوك فييد","footer":"© 2023 عيادة سمايل ارت ، جميع الحقوق محفوظة","friday":"الجمعة","full_name":"الاسم","gallery":"معرض الصور","headquarter":"الفرع الرئيسي","home":"الرئيسية","home_banner_subtitle":"بادر بالحجز الآن واستمتع بعروض البلاك فريداي","home_banner_title":"نعمل دائماً من أجل راحتكم","instagram_feed":"انستجرام فييد","know_more":"اعرف المزيد","message":"الرسالة","monday":"الإثنين","more":"المزيد","name":"الاسم","offers":"العروض","phone_number":"رقم هاتف للتواصل","placeholder_message":"يرجى كتابة رسالتك هنا ","placeholder_name":"يرجى كتابة اسمك الثلاثي","placeholder_phone":"يرجى كتابة رقم الهاتف الخاص بك ","reach_us":"تواصل معنا عبر الهاتف أو البريد الإلكتروني من {{fromDay}} إلى {{toDay}}, {{fromTime}} - {{toTime}}","read_more":"اقرأ المزيد","saturday":"السبت","send_message":"ابعتلنا رسالة","services":"خدماتنا","services_banner_subtitle":"جميع الخدمات تقدم على أعلى مستوى وباستخدام أحدث الأجهزة","services_banner_title":"خدمات سمايل آرت","services_details":"تفاصيل الخدمات","sunday":"الأحد","team":"فريق العمل","team_banner_subtitle":"فريق متخصص يعما دائما من أجل راحتكم","team_banner_title":"فريق عمل سمايل آرت","team_members":"أفراد الفريق","thursday":"الخميس","title":"عيادة سمايل ارت، ٢٠ عاما من العطاء","tuesday":"الثلاثاء","view_more":"عرض المزيد","wednesday":"الأربعاء","why_smileart":"لماذا سمايل آرت؟","google_reviews":"آراء العملاء (جوجل)","facebook_reviews":"آراء العملاء (فيسبوك)","reviews":"آراء العملاء","articles":"المقالات","related_articles":"مقالات ذات صلة","service":"الخدمة","name_required":"يجب كتابة الاسم","phone_required":"يجب كتابة رقم الهاتف","email_required":"يجيب كتابة الايميل","message_required":"يجب كتابة رسالة","email_sent_error":"خطأ. يرجى المحالولة في وقت لاحق","email_sent_success":"تم الارسال بنجاح","branches":"الفروع","workhours":"أوقات العمل"}');

/***/ }),

/***/ 9748:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"about_dr_magdy":"Who is Dr. Magdy?","address":"92 Sayed Zakeria st., Sheraton, Cairo,Egypt.","ahmed_sami":"Ahmed Sami","articles":"Articles","book_now":"Book Now","call_us":"Call us","clients":"Testmonials","contact_us":"Contact Us","data_load_issue":"No data to show right now","developed_by":"Developed with ","dr_magdy":"Dr. Magdy El Ghamry","email":"E-Mail","facebook_feed":"Facebook Feed","facebook_reviews":"Facebook Reviews","footer":"© 2023 Smile Art Clinic, All Rights Reserved","friday":"Friday","full_name":"Name","gallery":"Gallery","google_reviews":"Google Reviews","headquarter":"Headquarter","home":"Home","home_banner_subtitle":"Book Now and Enjoy Black Friday Offers","home_banner_title":"We are always working for your comfort","instagram_feed":"Instgram Feed","know_more":"Know More","message":"Message","monday":"Monday","more":"More","name":"Name","offers":"Offers","phone_number":"Phone Number","placeholder_message":"Please write your message here","placeholder_name":"Please write your full name","placeholder_phone":"Please write your phone number","reach_us":"Reach us by phone or email from {{fromDay}} to {{toDay}}, {{fromTime}} - {{toTime}}","read_more":"Read More","reviews":"Reviews","saturday":"Saturday","send_message":"Send us a message","services":"Services","services_banner_subtitle":"All services are provided at the highest level using the most modern equipment.","services_banner_title":"Smile Art Services","services_details":"Services Details","sunday":"Sunday","team":"Team","team_banner_subtitle":"A specialized team always works for your convenience","team_banner_title":"Smile Art team","team_members":"Team Members","thursday":"Thursday","title":"Smile Art Clinic, 20 years of smiling.","tuesday":"Tuesday","view_more":"View More","wednesday":"Wednesday","why_smileart":"Why Smile Art?","related_articles":"Related Articles","service":"Service","name_required":"Name Required","phone_required":"phone Required","email_required":"Email Required","message_required":"Message Required","email_sent_error":"Error. Please try again later","email_sent_success":"Email sent successfully","workhours":"Work Hours","branches":"Branches"}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [274,298,184], () => (__webpack_exec__(3675)));
module.exports = __webpack_exports__;

})();